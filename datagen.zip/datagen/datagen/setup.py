from setuptools import setup

setup(name='datagen',
        version='0.0.1',
        description='Generate Random Data Index wise',
        packages=['datagen'],
        author_email='ranjitmaity95@gmail.com',
        zip_safe=False,
        long_description_content_type="text/markdown",
        long_description=open('README.md').read(),
        )