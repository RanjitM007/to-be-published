import string,random,re 
class data:
    def __init__self():
        self.self=self
    def generate(self,strng):
        try:
    
            regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
            if(regex.search(strng) == None):
                print("String is accepted")
                a=0
            else:
                print("String is not accepted.")
                a=1
            if a==0:
                output=''
                for i in strng:
                    if i.isalpha()==True:
                        if i.isupper()==True:
                            ran = ''.join(random.choices(string.ascii_uppercase, k = 1))
                            output=output+ran
                        else:
                            ran = ''.join(random.choices(string.ascii_lowercase, k = 1))
                            output=output+ran
                    else:
                        ran = ''.join(random.choices(string.digits, k = 1))
                        output=output+ran
            return output
        except:
            pass