
# Random Data Generator

With this library you can Generate the data Index wise i.e:
example :
![demo](https://github.com/RanjitM007/Images/blob/main/P%20y%20t%20h%20o%20N%201%202%203.gif?raw=true)


## 🔗 Links

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ranjit-maity-75204a131/)
[![twitter](https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/ranjitmaity95)

## Usage/Examples

```python
! pip install datgen
```
```python
import datagen as data
```
```python
result=data.generate(string)


```


